# SchoolFlow — Android timetable

A small native Android app for the supplied Monday–Friday timetable. Includes a home-screen widget, next-lesson countdown, week tabs, and editable classroom labels.

## Build
1. Install Android Studio (Hedgehog or newer) and Android SDK 35.
2. Open this folder (`SchoolFlow`) in Android Studio.
3. Allow Gradle sync; use JDK 17 or the JDK bundled with Android Studio.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Install `app/build/outputs/apk/debug/app-debug.apk` on the Samsung phone.

## Add the widget
Long-press an empty area of the home screen → Widgets → SchoolFlow → drag the widget onto the screen.

## Notes
- Friday has no first lesson; Geography starts at period 2 (09:20).
- Bell schedule: 08:30–09:10, 09:20–10:00, 10:20–11:00, 11:15–11:55, 12:10–12:50, 13:00–13:40, 13:50–14:30.
- Classroom numbers can be added by tapping the plus sign beside a lesson.
- This first build is local-only; it does not connect to Gosuslugi My School and does not request account credentials.
- Android launchers control widget refresh frequency; countdown refresh may not tick every minute on every Samsung/One UI version.
- Lock-screen widgets are not universally supported by Samsung One UI. The home-screen widget is supported.
