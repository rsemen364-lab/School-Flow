package com.semen.schoolflow

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.time.DayOfWeek
import java.time.LocalDate

class MainActivity : Activity() {
    private val purple = Color.rgb(169, 151, 255)
    private val prefs by lazy { getSharedPreferences("rooms", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); render(DayOfWeek.from(LocalDate.now())) }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun render(selected: DayOfWeek) {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(24),dp(20),dp(20)); setBackgroundColor(Color.rgb(16,17,26)) }
        val scroll = ScrollView(this); val content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        content.addView(text("SCHOOLFLOW",12,purple,true)); content.addView(text("Твоё расписание",30,Color.WHITE,true))
        content.addView(text("Уроки, перемены и всё под рукой",14,0xFF9A9CAE.toInt(),false))
        val next = Schedule.next()
        val hero = card().apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(18)) }
        hero.addView(text("СЛЕДУЮЩИЙ УРОК",11,purple,true))
        hero.addView(text(next?.first?.name ?: "На сегодня всё",24,Color.WHITE,true))
        hero.addView(text(if(next!=null) "Начало в ${next.first.start} · через ${next.second} мин" else "Можно отдыхать",14,0xFFC7C6D5.toInt(),false))
        content.addView(hero, margin(0,dp(20),0,dp(18)))
        val tabs = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf(DayOfWeek.MONDAY,DayOfWeek.TUESDAY,DayOfWeek.WEDNESDAY,DayOfWeek.THURSDAY,DayOfWeek.FRIDAY).forEach { day ->
            val b=TextView(this).apply { text=listOf("ПН","ВТ","СР","ЧТ","ПТ")[day.value-1]; gravity=Gravity.CENTER; textSize=12f; setTextColor(if(day==selected) Color.WHITE else 0xFF9698AA.toInt()); setPadding(dp(10),dp(12),dp(10),dp(12)); setBackgroundColor(if(day==selected) 0xFF51418D.toInt() else Color.TRANSPARENT); setOnClickListener { render(day) } }
            tabs.addView(b,LinearLayout.LayoutParams(0,dp(44),1f))
        }
        content.addView(tabs,margin(0,0,0,dp(12)))
        content.addView(text(Schedule.dayName(selected),21,Color.WHITE,true))
        Schedule.lessons(selected).forEachIndexed { i, lesson ->
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(14),dp(13),dp(14),dp(13)); setBackgroundColor(0xFF1C1F2E.toInt()) }
            val number=text("${i+1}",16,purple,true); row.addView(number,LinearLayout.LayoutParams(dp(30),-2))
            val names=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
            names.addView(text(lesson.name,15,Color.WHITE,true)); names.addView(text("${lesson.start} — ${lesson.end}",12,0xFF999BAD.toInt(),false))
            row.addView(names,LinearLayout.LayoutParams(0,-2,1f))
            val room=prefs.getString("${selected.value}_${i}","").orEmpty()
            row.addView(text(if(room.isBlank()) "＋" else "№$room",13,purple,true).apply { setOnClickListener { editRoom(selected,i,lesson.name) } })
            content.addView(row,margin(0,dp(5),0,0))
        }
        content.addView(text("Нажми на ＋, чтобы указать кабинет. Виджет добавляется через меню виджетов Samsung → SchoolFlow.",12,0xFF85889B.toInt(),false).apply { setPadding(0,dp(16),0,dp(12)) })
        setContentView(root)
    }
    private fun text(s:String,size:Int,color:Int,bold:Boolean)=TextView(this).apply { text=s; textSize=size.toFloat(); setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD; setPadding(0,dp(3),0,dp(3)) }
    private fun card()=LinearLayout(this).apply { setBackgroundColor(0xFF28243F.toInt()) }
    private fun margin(l:Int,t:Int,r:Int,b:Int)=LinearLayout.LayoutParams(-1,-2).apply { setMargins(l,t,r,b) }
    private fun editRoom(day:DayOfWeek,index:Int,subject:String) {
        val input=EditText(this).apply { hint="Например, 214"; setText(prefs.getString("${day.value}_$index","")); inputType=android.text.InputType.TYPE_CLASS_TEXT }
        AlertDialog.Builder(this).setTitle("Кабинет · $subject").setView(input).setPositiveButton("Сохранить") { _,_-> prefs.edit().putString("${day.value}_$index",input.text.toString()).apply(); render(day); refreshWidget() }.setNegativeButton("Отмена",null).show()
    }
    private fun refreshWidget() { val i=Intent(this,ScheduleWidget::class.java).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE); i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS,AppWidgetManager.getInstance(this).getAppWidgetIds(ComponentName(this,ScheduleWidget::class.java))); sendBroadcast(i) }
}
