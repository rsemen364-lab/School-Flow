package com.semen.schoolflow

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDateTime

class ScheduleWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = update(context, manager, ids)
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_UPDATE) update(context, AppWidgetManager.getInstance(context), AppWidgetManager.getInstance(context).getAppWidgetIds(android.content.ComponentName(context, ScheduleWidget::class.java)))
    }
    companion object {
        const val ACTION_UPDATE = "com.semen.schoolflow.UPDATE_WIDGET"
        fun update(context: Context, manager: AppWidgetManager, ids: IntArray) {
            val now = LocalDateTime.now(); val next = Schedule.next(now)
            ids.forEach { id ->
                val views = RemoteViews(context.packageName, R.layout.widget)
                views.setTextViewText(R.id.widget_day, "SCHOOLFLOW · ${Schedule.dayName(now.dayOfWeek).uppercase()}")
                if (next == null) {
                    views.setTextViewText(R.id.widget_subject, "Уроков больше нет")
                    views.setTextViewText(R.id.widget_time, "Хорошего отдыха!")
                    views.setTextViewText(R.id.widget_room, "")
                } else {
                    val (lesson, mins) = next
                    views.setTextViewText(R.id.widget_subject, lesson.name)
                    views.setTextViewText(R.id.widget_time, "${lesson.start} · через ${if (mins < 60) "$mins мин" else "${mins/60} ч ${mins%60} мин"}")
                    views.setTextViewText(R.id.widget_room, "Кабинет можно добавить в приложении")
                }
                val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                views.setOnClickPendingIntent(R.id.widget_subject, open)
                manager.updateAppWidget(id, views)
            }
        }
    }
}
