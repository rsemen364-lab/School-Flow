package com.semen.schoolflow

import java.time.*

data class Lesson(val name: String, val start: String, val end: String)
object Schedule {
    val days = linkedMapOf(
        DayOfWeek.MONDAY to listOf("Классный час","Русский язык","Литература","История","Английский язык","Биология","Музыка"),
        DayOfWeek.TUESDAY to listOf("Технология","Технология","Математика","Математика","Русский язык","Литература"),
        DayOfWeek.WEDNESDAY to listOf("Русский язык","Литература","Математика","Математика","Английский язык","Физкультура","Математика"),
        DayOfWeek.THURSDAY to listOf("Профориентация","Русский язык","Русский язык","Математика","ИЗО","Физкультура","История"),
        DayOfWeek.FRIDAY to listOf("География","Русский язык","Математика","Информатика","История","Английский язык")
    )
    val times = listOf("08:30" to "09:10", "09:20" to "10:00", "10:20" to "11:00", "11:15" to "11:55", "12:10" to "12:50", "13:00" to "13:40", "13:50" to "14:30")
    fun lessons(day: DayOfWeek): List<Lesson> = (days[day] ?: emptyList()).mapIndexed { i, n ->
        val slot = if (day == DayOfWeek.FRIDAY) i + 1 else i
        Lesson(n, times[slot].first, times[slot].second)
    }
    fun next(now: LocalDateTime = LocalDateTime.now()): Pair<Lesson, Long>? {
        for (offset in 0..7) {
            val date = now.toLocalDate().plusDays(offset.toLong())
            val dayLessons = lessons(date.dayOfWeek)
            for (lesson in dayLessons) {
                val start = LocalDateTime.of(date, LocalTime.parse(lesson.start))
                if (start.isAfter(now)) return lesson to Duration.between(now, start).toMinutes()
            }
        }
        return null
    }
    fun dayName(day: DayOfWeek) = when(day) { DayOfWeek.MONDAY->"Понедельник"; DayOfWeek.TUESDAY->"Вторник"; DayOfWeek.WEDNESDAY->"Среда"; DayOfWeek.THURSDAY->"Четверг"; DayOfWeek.FRIDAY->"Пятница"; else->"Выходной" }
}
